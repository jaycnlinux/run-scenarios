#!/bin/bash
/usr/bin/python ./auto_backup_vm.py
