#!/usr/bin/env python
# -*- coding: UTF-8 -*-

__author__ = 'niuben'
__date__ = '2017/09/27'

# import modules here
import ConfigParser
import datetime
import json
import re
import sys
import time
import urllib2


# write code here
CONF_PATH = './conf/dazhihui.conf'
AUTH_REQ_TEMPLATE_JSON_PATH = './conf/auth_req_template.json'
AUTH_REQ_DATA_JSON_PATH = './conf/auth_req_data.json'
EXPORT_IMAGE_TEMPLATE_JSON_PATH = './conf/export_image_template.json'
EXPORT_IMAGE_DATA_JSON_PATH = './conf/export_image_data.json'
CREATE_VOLUME_TEMPLATE_JSON_PATH = './conf/create_volume_template.json'
CREATE_VOLUME_DATA_JSON_PATH = './conf/create_volume_data.json'
CREATE_VM_TEMPLATE_JSON_PATH = './conf/create_vm_template.json'
CREATE_VM_DATA_JSON_PATH = './conf/create_vm_data.json'


RT_NO_CONF_FILE = 1
RT_SNAPSHOT_NOT_OK = 2
RT_LACK_OF_CMD_PARAMS = 10


def get_conf():
    conf = ConfigParser.ConfigParser()
    if not conf.read(CONF_PATH):
        return {}
    scheme = conf.get('api_conf', 'scheme')
    iam_domain = conf.get('api_conf', 'iam_domain')
    ecs_domain = conf.get('api_conf', 'ecs_domain')
    evs_domain = conf.get('api_conf', 'evs_domain')
    ims_domain = conf.get('api_conf', 'ims_domain')
    port = conf.get('api_conf', 'port')
    tenant_id = conf.get('api_conf', 'tenant_id')
    server_id = sys.argv[1]
    server_name = sys.argv[2]
    name = conf.get('api_conf', 'name')
    pwd = conf.get('api_conf', 'pwd')
    image_name = server_name + '-' + datetime.datetime.now().strftime("%Y%m%d")
    expired_time = conf.get('image_conf', 'expired_time')
    flavor_ref = sys.argv[3]
    az = sys.argv[4]
    volume_type_sys = sys.argv[5]
    volume_type_data = sys.argv[6]

    conf_dict = {
        'scheme': scheme,
        'iam_domain': iam_domain,
        'ecs_domain': ecs_domain,
        'evs_domain': evs_domain,
        'ims_domain': ims_domain,
        'port': port,
        'tenant_id': tenant_id,
        'server_id': server_id,
        'name': name,
        'pwd': pwd,
        'image_name': image_name,
        'expired_time': expired_time,
        'flavor_ref': flavor_ref,
        'az': az,
        'volume_type_sys': volume_type_sys,
        'volume_type_data': volume_type_data,
    }

    return conf_dict

def get_urls():
    conf = get_conf()
    if not conf:
        sys.exit(RT_NO_CONF_FILE)

    auth_path = '/v3/auth/tokens'
    export_image_path = '/v2/%s/servers/%s/action' % (conf['tenant_id'],
                                                      conf['server_id'])
    list_image_path = '/v2/images'
    delete_image_path = '/v2/%s/images' % conf['tenant_id']
    create_snapshot_volume_path = '/v2/%s/volumes' % conf['tenant_id']
    create_vm_with_snapshot_volume_path = '/v2/%s/servers' % conf['tenant_id']

    iam_url = conf['scheme'] + '://' + conf['iam_domain'] + ':' + conf['port']
    ecs_url = conf['scheme'] + '://' + conf['ecs_domain'] + ':' + conf['port']
    ims_url = conf['scheme'] + '://' + conf['ims_domain'] + ':' + conf['port']

    url_dict = {
        'auth_url': iam_url + auth_path,
        'export_image_url': ecs_url + export_image_path,
        'list_image_url': ims_url + list_image_path,
        'delete_image_url': ims_url + delete_image_path,
    }
    return url_dict

def generate_auth_json():
    conf = get_conf()
    with open(AUTH_REQ_TEMPLATE_JSON_PATH, 'r') as f:
        data = json.load(f)
       
        data['auth']['identity']['password']['user']['domain']['name'] = \
            conf['name']
        data['auth']['identity']['password']['user']['password'] = conf[
            'pwd']
        data['auth']['identity']['password']['user']['name'] = conf['name']
        data['auth']['scope']['project']['id'] = conf['tenant_id']

        with open(AUTH_REQ_DATA_JSON_PATH, 'w') as f:
            json.dump(data, f)

def get_token(auth_url):
    generate_auth_json()
    with open(AUTH_REQ_DATA_JSON_PATH, 'r') as f:
        data = json.load(f)
        auth_req = urllib2.Request(auth_url, json.dumps(data))
        auth_req.add_header('Content-Type', 'application/json')
        auth_resp = urllib2.urlopen(auth_req)
        if auth_resp.headers.has_key('x-subject-token'):
    
            return auth_resp.headers['x-subject-token']

def handle_request(url, token, data_path=None, method='GET'):
    if data_path is not None:
        with open(data_path, 'r') as f:
            data = json.load(f)
            req = urllib2.Request(url, json.dumps(data))
    else:
        req = urllib2.Request(url)
    if method != 'GET':
        req.get_method = lambda : method
    req.add_header('Content-Type', 'application/json')
    req.add_header('X-Auth-Token', token)
    resp = urllib2.urlopen(req)
    return resp

def generate_export_image_json():
    conf = get_conf()
    with open(EXPORT_IMAGE_TEMPLATE_JSON_PATH, 'r') as f:
        data = json.load(f)
       
        data['createImage']['name'] = conf['image_name']
        data['createImage']['metadata'] = {'flavor_ref': conf['flavor_ref']}
        data['createImage']['metadata'].update({'az': conf['az']})
        data['createImage']['metadata'].update({'volume_type_sys': conf['volume_type_sys']})
        data['createImage']['metadata'].update({'volume_type_data': conf['volume_type_data']})
       

        with open(EXPORT_IMAGE_DATA_JSON_PATH, 'w') as f:
            json.dump(data, f)

def export_image(export_image_url, token):
    generate_export_image_json()
    return handle_request(export_image_url, token,
                    data_path=EXPORT_IMAGE_DATA_JSON_PATH)

def list_image(list_image_url, token):
    return handle_request(list_image_url, token)

def get_current_image_name():
    conf = get_conf()
    return conf['image_name']

def check_image_is_active(list_image_url):
    name = get_current_image_name()
    list_image_resp = list_image(list_image_url, token)
    list_image_json = json.load(list_image_resp)

    for image in list_image_json['images']:
        if image['name'] == name and image['status'] == 'active':
            return True
    return False

def check_image_is_ok(list_image_url):
    for i in xrange(0, 10):
        if check_image_is_active(list_image_url):
            print 'image is active!'
            return True
        time.sleep(3)
    return False

def cleanup_old_image(list_image_url):
    conf = get_conf()
    list_image_resp = list_image(list_image_url, token)
    list_image_json = json.load(list_image_resp)

    now = int(datetime.datetime.now().strftime("%Y%m%d"))
    expired_time = int(conf['expired_time'])
    pattern = re.compile(r'\w+\-(\d{8})$')
    for image in list_image_json['images']:
        match = pattern.search(image['name'])
        print image['name']
        if match:
            created_date = int(match.group(1))
            if now - created_date > expired_time:
                print 'image %s is expired, will be deleted! '
                cleanup_image_url = urls['delete_image_url'] + '/' + image[
                    'id']
                handle_request(cleanup_image_url, token, method='DELETE')

# main func
if __name__ == '__main__':

    if len(sys.argv) < 3:
        print 'lack of cmd params!'
        sys.exit(RT_LACK_OF_CMD_PARAMS)

    urls = get_urls()
 

    token = get_token(urls['auth_url'])

    export_image(urls['export_image_url'], token)

    if not check_image_is_ok(urls['list_image_url']):
        sys.exit(RT_SNAPSHOT_NOT_OK)
    else:
        cleanup_old_image(urls['list_image_url'])
