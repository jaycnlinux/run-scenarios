#!/bin/bash

while read line
do
    echo "File:${line}"
    arg_1=`echo ${line} | awk '{print $1}'`
    arg_2=`echo ${line} | awk '{print $2}'`
    python ./auto_snapshot.py $arg_1 $arg_2
    echo '=================='
done < ./conf/vm_list.conf

