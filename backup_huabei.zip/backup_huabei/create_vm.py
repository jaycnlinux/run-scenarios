#!/usr/bin/env python
# -*- coding: UTF-8 -*-

__author__ = 'niuben'
__date__ = '2017/09/27'

# import modules here
import ConfigParser
import datetime
import json
import sys
import time
import urllib2


# write code here
CONF_PATH = './conf/dazhihui.conf'
AUTH_REQ_TEMPLATE_JSON_PATH = './conf/auth_req_template.json'
AUTH_REQ_DATA_JSON_PATH = './conf/auth_req_data.json'
EXPORT_IMAGE_TEMPLATE_JSON_PATH = './conf/export_image_template.json'
EXPORT_IMAGE_DATA_JSON_PATH = './conf/export_image_data.json'
CREATE_VOLUME_TEMPLATE_JSON_PATH = './conf/create_volume_template.json'
CREATE_VOLUME_DATA_JSON_PATH = './conf/create_volume_data.json'
CREATE_VM_TEMPLATE_JSON_PATH = './conf/create_vm_template.json'
CREATE_VM_DATA_JSON_PATH = './conf/create_vm_data.json'


RT_NO_CONF_FILE = 1
RT_SNAPSHOT_NOT_OK = 2
RT_SNAPSHOT_NOT_FOUND = 3
RT_SYS_VOL_NOT_FOUND = 4
RT_LACK_OF_CMD_PARAMS = 10


def get_conf():
    conf = ConfigParser.ConfigParser()
    if not conf.read(CONF_PATH):
        return {}
    scheme = conf.get('api_conf', 'scheme')
    iam_domain = conf.get('api_conf', 'iam_domain')
    ecs_domain = conf.get('api_conf', 'ecs_domain')
    evs_domain = conf.get('api_conf', 'evs_domain')
    ims_domain = conf.get('api_conf', 'ims_domain')
    port = conf.get('api_conf', 'port')
    tenant_id = conf.get('api_conf', 'tenant_id')
    name = conf.get('api_conf', 'name')
    pwd = conf.get('api_conf', 'pwd')
    image_name = sys.argv[1]

    volume_availability_zone = conf.get('volume_conf', 'availability_zone')
    volume_type = conf.get('volume_conf', 'volume_type')
    volume_size = conf.get('volume_conf', 'size')

    vm_availability_zone = conf.get('vm_conf', 'availability_zone')
    flavor_ref = conf.get('vm_conf', 'flavor_ref')
    net_uuid = conf.get('vm_conf', 'net_uuid')

    conf_dict = {
        'scheme': scheme,
        'iam_domain': iam_domain,
        'ecs_domain': ecs_domain,
        'evs_domain': evs_domain,
        'ims_domain': ims_domain,
        'port': port,
        'tenant_id': tenant_id,
        'name': name,
        'pwd': pwd,
        'image_name': image_name,
        'volume_name': image_name,
        'vm_name': image_name,
        'volume_availability_zone': volume_availability_zone,
        'volume_type': volume_type,
        'volume_size': volume_size,
        'vm_availability_zone': vm_availability_zone,
        'flavor_ref': flavor_ref,
        'net_uuid': net_uuid,
    }

    return conf_dict

def get_urls():
    if not conf:
        sys.exit(RT_NO_CONF_FILE)

    auth_path = '/v3/auth/tokens'
    list_image_path = '/v2/images'
    create_snapshot_volume_path = '/v2/%s/volumes' % conf['tenant_id']
    create_vm_with_snapshot_volume_path = '/v2/%s/servers' % conf['tenant_id']
    list_volume_path = '/v2/%s/volumes/detail' % conf['tenant_id']

    iam_url = conf['scheme'] + '://' + conf['iam_domain'] + ':' + conf['port']
    ecs_url = conf['scheme'] + '://' + conf['ecs_domain'] + ':' + conf['port']
    evs_url = conf['scheme'] + '://' + conf['evs_domain'] + ':' + conf['port']
    ims_url = conf['scheme'] + '://' + conf['ims_domain'] + ':' + conf['port']

    url_dict = {
        'auth_url': iam_url + auth_path,
        'list_image_url': ims_url + list_image_path,
        'create_snapshot_volume_url': evs_url + create_snapshot_volume_path,
        'create_vm_with_snapshot_volume_url':
            ecs_url + create_vm_with_snapshot_volume_path,
        'list_volume_url': evs_url + list_volume_path,
    }
    return url_dict

def generate_auth_json():
    with open(AUTH_REQ_TEMPLATE_JSON_PATH, 'r') as f:
        data = json.load(f)
        data['auth']['identity']['password']['user']['domain']['name'] = \
            conf['name']
        data['auth']['identity']['password']['user']['password'] = conf[
            'pwd']
        data['auth']['identity']['password']['user']['name'] = conf['name']
        data['auth']['scope']['project']['id'] = conf['tenant_id']

        with open(AUTH_REQ_DATA_JSON_PATH, 'w') as f:
            json.dump(data, f)

def get_token(auth_url):
    generate_auth_json()
    with open(AUTH_REQ_DATA_JSON_PATH, 'r') as f:
        data = json.load(f)
        auth_req = urllib2.Request(auth_url, json.dumps(data))
        auth_req.add_header('Content-Type', 'application/json')
        auth_resp = urllib2.urlopen(auth_req)
        if auth_resp.headers.has_key('x-subject-token'):
            return auth_resp.headers['x-subject-token']

def handle_request(url, token, data_path=None):
    if data_path is not None:
        with open(data_path, 'r') as f:
            data = json.load(f)
            req = urllib2.Request(url, json.dumps(data))
    else:
        req = urllib2.Request(url)
    req.add_header('Content-Type', 'application/json')
    req.add_header('X-Auth-Token', token)
    resp = urllib2.urlopen(req)
    return resp

def generate_export_image_json():
    with open(EXPORT_IMAGE_TEMPLATE_JSON_PATH, 'r') as f:
        data = json.load(f)
        print data
        data['createImage']['name'] = conf['image_name']
        print data

        with open(EXPORT_IMAGE_DATA_JSON_PATH, 'w') as f:
            json.dump(data, f)

def list_image(list_image_url, token):
    return handle_request(list_image_url, token)

def get_snapshot_ids(list_image_url, token):
    name = conf['image_name']
    list_image_resp = list_image(list_image_url, token)
    list_image_json = json.load(list_image_resp)

    snapshot_ids = {}
    for image in list_image_json['images']:
        if image['name'] == name and image['status'] == 'active':
            for bdm in json.loads(image['block_device_mapping']):
                if bdm['boot_index'] == 0:
                    snapshot_ids['sys'] = bdm['snapshot_id']
                else:
                    snapshot_ids['data'] = bdm['snapshot_id']
    print 'snapshot_ids: %s' % snapshot_ids
    return snapshot_ids

def generate_create_volume_json(snapshot_id, is_sys_volume=False):
    with open(CREATE_VOLUME_TEMPLATE_JSON_PATH, 'r') as f:
        data = json.load(f)
        import pdb;pdb.set_trace()
        volume_name = conf['volume_name']

        if is_sys_volume:
            volume_name += '-sys'
        else:
            volume_name += '-data'

        data['volume']['name'] = volume_name
        data['volume']['availability_zone'] = conf['volume_availability_zone']
        data['volume']['volume_type'] = conf['volume_type']
        data['volume']['size '] = conf['volume_size']
        data['volume']['snapshot_id'] = snapshot_id

        with open(CREATE_VOLUME_DATA_JSON_PATH, 'w') as ff:
            json.dump(data, ff)

def create_volume_by_snapshots():
    token = get_token(urls['auth_url'])
    snapshot_ids = get_snapshot_ids(urls['list_image_url'], token)

    if 'sys' not in snapshot_ids:
        print 'snapshot not found!'
        sys.exit(RT_SNAPSHOT_NOT_FOUND)

    # create sys volume
    generate_create_volume_json(snapshot_ids['sys'], is_sys_volume=True)
    handle_request(urls['create_snapshot_volume_url'], token,
                   data_path=CREATE_VOLUME_DATA_JSON_PATH)

    # create data volume
    if 'data' in snapshot_ids:
        generate_create_volume_json(snapshot_ids['data'])
        handle_request(urls['create_snapshot_volume_url'], token,
                       data_path=CREATE_VOLUME_DATA_JSON_PATH)

def list_volume(token):
    return handle_request(urls['list_volume_url'], token)

def get_volume_ids(token):
    name = conf['volume_name']
    sys_volume_name = name + '-sys'
    data_volume_name = name + '-data'
    list_volume_resp = list_volume(token)
    list_volume_json = json.load(list_volume_resp)

    volume_ids = {}
    for volume in list_volume_json['volumes']:
        if volume['status'] == 'available':
            if volume['name'] == sys_volume_name:
                volume_ids['sys'] = volume['id']
            elif volume['name'] == data_volume_name:
                volume_ids['data'] = volume['id']
    if 'sys' not in volume_ids:
        print 'system volume not found!'
        sys.exit(RT_SYS_VOL_NOT_FOUND)
    return volume_ids

def generate_create_vm_json(token):
    with open(CREATE_VM_TEMPLATE_JSON_PATH, 'r') as f:
        data = json.load(f)

        data['server']['name'] = conf['vm_name']
        data['server']['availability_zone'] = conf['vm_availability_zone']
        data['server']['flavorRef'] = conf['flavor_ref']
        data['server']['networks'][0]['uuid'] = conf['net_uuid']
        data['server']['block_device_mapping_v2'][0]['boot_index'] = 0

        volume_ids = get_volume_ids(token)
        data['server']['block_device_mapping_v2'][0]['uuid'] = volume_ids[
            'sys']
        if 'data' in volume_ids:
            data['server']['block_device_mapping_v2'][1]['uuid'] = \
                volume_ids['data']

        with open(CREATE_VM_DATA_JSON_PATH, 'w') as f:
            json.dump(data, f)

def create_vm_by_volume():
    token = get_token(urls['auth_url'])
    generate_create_vm_json(token)

    handle_request(urls['create_vm_with_snapshot_volume_url'], token,
                   data_path=CREATE_VM_DATA_JSON_PATH)


# main func
if __name__ == '__main__':

    if len(sys.argv) < 2:
        print 'lack of cmd params!'
        sys.exit(RT_LACK_OF_CMD_PARAMS)

    conf = get_conf()
    urls = get_urls()
    print urls
    #import pdb;pdb.set_trace()
    #create_volume_by_snapshots()
    #create_vm_by_volume()
    token = get_token(urls['auth_url'])
    list_volume(token)
    import pdb;

    pdb.set_trace()