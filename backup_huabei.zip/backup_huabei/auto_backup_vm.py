#!/usr/bin/env python
# -*- coding: UTF-8 -*-

__author__ = 'niuben'
__date__ = '2017/09/27'

# import modules here
import os

# write code here

# main func
if __name__ == '__main__':
    input = open('./conf/vm_list.conf', 'r')
    params = input.readlines()

    for param in params:
        param_list = param.split()
        os.system('python ./auto_snapshot.py ' + param_list[0] + ' ' +
                  param_list[1] + ' ' + param_list[2] + ' ' + param_list[3] + ' ' +
                  param_list[4] + ' ' + param_list[5])
